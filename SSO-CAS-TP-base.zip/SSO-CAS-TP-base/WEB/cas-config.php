<?php
define('CAS_HOST','cbCAS');
define('CAS_PORT',8443);
define('CAS_URL','/cas');
define('CAS_CERT','/home/cb/L3-SSO-CAS/cas.crt');
?>
